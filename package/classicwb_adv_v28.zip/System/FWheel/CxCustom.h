
extern int MouseSpeed;
extern BOOL DoClickToFront;

void CxCustomRoutine(CxMsg *msg,CxObj *obj);

