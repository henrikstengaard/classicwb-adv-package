/*************************************************************
*   TestFreshPalette.c
*   Written by Christian Taulien
*   � Copyright 1996 by Christian Taulien of Strange Intelligence
*   Version 1.0
*   Last change: 20. September 1996
*   Language: SAS/C 6.56 (should also run under earlier versions)
          or  MAXON C/C++ 3.1
*/

#include <stdio.h>
#include <string.h>
#include <exec/types.h>

#ifdef __SASC
#include <clib/dos_protos.h>
#include <dos.h>
#endif

#ifdef __MAXON__
#include <pragma/dos_lib.h>
#include <dos/dos.h>
#endif

#define MAX_PSV_LEN 256

char varname[]="PALETTESET";        /* Name of the ENV-Variable we want to investigate */
char buf[MAX_PSV_LEN];              /* The buffer to hold the value of the ENV-Variable */
LONG    buflen=MAX_PSV_LEN;
ULONG   flags=LV_VAR | GVF_GLOBAL_ONLY;
LONG    count;

void main(void)
{
    count=GetVar(varname,buf,buflen,flags);
    if (-1 == count)        /* if an error occured */
    {
        LONG errorcode;
            errorcode=IoErr();
            switch (errorcode)
            {
                case ERROR_OBJECT_NOT_FOUND:
                    printf("No ENV-Variable \"PALETTESET\" found.\nThe FreshPalette is not active.\n");
                    break;
                case ERROR_BAD_NUMBER:
                    printf("You gave zero for wanted var-len!\nThe FreshPalette is not active.\n");
                    break;
            }
    }
    else                    /* if everything is ok. */
    {
        printf("The value of the \"PALETTESET\"-ENV-Variable is:\n%s\nIts length is:%d\n",buf,count);
        if (!strcmp((const char *) buf,"FRESH"))
            printf("The FreshPalette is active.\n");
        else
            printf("The FreshPalette is not active.\n");
    }
}
