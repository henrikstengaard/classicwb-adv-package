#include <proto/dos.h>
#include <proto/exec.h>

#include "fs/packets.h"
#include "fs/query.h"

static const char version[] __attribute__((used)) = "\0$VER: SFSquery 1.2 (16.2.2005)\r\n";

int main(void)
{
   struct RDArgs *readarg;
   UBYTE template[]="DEVICE/A\n";
   struct {char *name;} arglist={NULL};

   readarg = IDOS->ReadArgs(template, (LONG *)&arglist, 0);
   if (0 != readarg)
   {
      struct MsgPort *msgport;
      struct DosList *dl;
      UBYTE *devname = arglist.name;

      while (*devname != 0)
      {
         if (*devname == ':')
         {
            *devname=0;
            break;
         }
         devname++;
      }

      dl = IDOS->LockDosList(LDF_DEVICES|LDF_READ);
      if (0 != (dl=IDOS->FindDosEntry(dl, arglist.name, LDF_DEVICES)))
      {
         LONG errorcode;

         struct TagItem tags[]={{ASQ_CACHE_ACCESSES, 0},
                                {ASQ_CACHE_MISSES, 0},

                                {ASQ_START_BYTEH, 0},
                                {ASQ_START_BYTEL, 0},
                                {ASQ_END_BYTEH, 0},
                                {ASQ_END_BYTEL, 0},
                                {ASQ_DEVICE_API, 0},

                                {ASQ_BLOCK_SIZE, 0},
                                {ASQ_TOTAL_BLOCKS, 0},

                                {ASQ_ROOTBLOCK, 0},
                                {ASQ_ROOTBLOCK_OBJECTNODES, 0},
                                {ASQ_ROOTBLOCK_EXTENTS, 0},
                                {ASQ_FIRST_BITMAP_BLOCK, 0},
                                {ASQ_FIRST_ADMINSPACE, 0},

                                {ASQ_CACHE_LINES, 0},
                                {ASQ_CACHE_READAHEADSIZE, 0},
                                {ASQ_CACHE_MODE, 0},
                                {ASQ_CACHE_BUFFERS, 0},

                                {ASQ_IS_CASESENSITIVE, 0},
                                {ASQ_HAS_RECYCLED, 0},

                                {ASQ_OPERATIONS_DECODED, 0},
                                {ASQ_EMPTY_OPERATIONS_DECODED, 0},

                                {ASQ_VERSION, 0},

                                {ASQ_MAX_NAME_LENGTH, 0},
                                {ASQ_ACTIVITY_FLUSH_TIMEOUT, 0},
                                {ASQ_INACTIVITY_FLUSH_TIMEOUT , 0},
                                {ASQ_MAX_RECYCLED_ENTRIES, 0},

                                {TAG_END, 0}
                               };

         msgport = dl->dol_Task;

         IDOS->Printf("SFSquery information for %s:", arglist.name);

         if (DOSFALSE != (errorcode=IDOS->DoPkt(msgport, ACTION_SFS_QUERY, (LONG)&tags, 0, 0, 0, 0)))
         {
            ULONG perc = 0;

            IDOS->UnLockDosList(LDF_DEVICES|LDF_READ);

            if (0 != tags[0].ti_Data)
            {
               perc = tags[1].ti_Data*100 / tags[0].ti_Data;
            }

            IDOS->Printf(" (SFS Version %lu.%lu)\n", tags[22].ti_Data>>16, tags[22].ti_Data&0xFFFF);
            IDOS->Printf("Start/end-offset : 0x%08lx:%08lx - 0x%08lx:%08lx bytes\n", tags[2].ti_Data, tags[3].ti_Data, tags[4].ti_Data, tags[5].ti_Data);
            IDOS->Printf("Device API       : ");

            switch(tags[6].ti_Data)
            {
               case ASQDA_NSD:
                  IDOS->Printf("NSD (64-bit)\n");
                  break;
               case ASQDA_TD64:
                  IDOS->Printf("TD64\n");
                  break;
               case ASQDA_SCSIDIRECT:
                  IDOS->Printf("SCSI direct\n");
                  break;
               default:
                  IDOS->Printf("(standard)\n");
                  break;
            }

            IDOS->Printf("Bytes/block      : %-12lU   Total blocks    : %lU\n", tags[7].ti_Data, tags[8].ti_Data);
            IDOS->Printf("Cache accesses   : %-12lU   Cache misses    : %lU (%lu%%)\n", tags[0].ti_Data, tags[1].ti_Data, perc);
            IDOS->Printf("Read-ahead cache : %lU x %lU bytes (%s)\n",tags[14].ti_Data, tags[15].ti_Data, tags[16].ti_Data != 0 ? "Copyback" : "Write-through");
            IDOS->Printf("Flush timeout    : act. %lus, inact. %lu%ss\n", tags[24].ti_Data, tags[25].ti_Data/2, tags[25].ti_Data&1 ? ".5" : "");
            IDOS->Printf("Max Name Length  : %lu\n", tags[23].ti_Data);
            IDOS->Printf("DOS buffers      : %lU\n", tags[17].ti_Data);

            IDOS->Printf("SFS settings     : ");

            if (0 != tags[18].ti_Data)
            {
               IDOS->Printf("[CASE SENSITIVE] ");
            }

            if (0 != tags[19].ti_Data)
            {
               IDOS->Printf("[RECYCLED, %lU entries] ", tags[26].ti_Data ?: 35);
            }

            IDOS->Printf("\n");
         } else {
            IDOS->UnLockDosList(LDF_DEVICES|LDF_READ);
            IDOS->Printf(" not SFS\n");
         }
      } else {
         IDOS->UnLockDosList(LDF_DEVICES|LDF_READ);
         IDOS->Printf("Couldn't find device '%s:'.\n", arglist.name);
      }

      IDOS->FreeArgs(readarg);
   } else {
      IDOS->PutErrStr("Wrong arguments!\n");
   }

   return 0;
}
