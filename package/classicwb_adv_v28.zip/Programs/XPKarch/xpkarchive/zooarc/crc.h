extern unsigned int crccode;

void addbfcrc(char *buffer,int count);
