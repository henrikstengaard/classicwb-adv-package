/*$Source: /usr/home/dhesi/zoo/RCS/ar.h,v $*/
/*$Id: ar.h,v 1.17 91/07/09 01:39:50 dhesi Exp $*/
/***********************************************************
   ar.h

Adapted from "ar" archiver written by Haruhiko Okumura.
***********************************************************/

#include <stdio.h>
#include <limits.h>
#include <libraries/xpkarchivesub.h>
#include "crc.h"

typedef unsigned char uchar;
typedef unsigned int   uint;    /* 16 bits or more */
typedef unsigned short ushort;  /* 16 bits or more */
typedef unsigned long  ulong;   /* 32 bits or more */

typedef ushort t_uint16;

/* ar.c */

extern int unpackable;
extern ulong origsize, compsize;

/* all the prototypes follow here for all files */

/* AR.C */
int get_line(char *s , int n );
void exitfunc(int code);
void dlog(char *fmt, ...);
void d1log(char *fmt, ...);
void outcf(FILE *stream, char *buf, int n);
void c1log(char *buf, int n);

/* DECODE.C */
void decode_start(void );
int decode(uint count , uchar buffer []);

/* ENCODE.C */
void encode(struct XarSubIO*);
void free_encode(void);

/* HUF.C */
void output(uint c , uint p );
void huf_encode_start(void );
void huf_encode_end(void );
uint decode_c(void );
uint decode_p(void );
void huf_decode_start(void );
void free_huf(void);

/* IO.C */
void make_crctable(void );
void fillbuf(int n );
uint getbits(int n );
void putbits(int n , uint x );
int fread_crc(uchar *p , int n , FILE *f );
void fwrite_crc(uchar *p , int n , FILE *f );
void init_getbits(void );
void init_putbits(void );

/* MAKETBL.C */
void make_table(int nchar, uchar bitlen[], int tablebits, ushort table[]);

/* MAKETREE.C */
int make_tree(int nparm, ushort freqparm [], uchar lenparm [], ushort codeparm []);

/* delete */

# define MOVE_LEFT memmove

/* for lzh modules and also for ar.c to use in defining buffer size */
#define DICBIT    13    /* 12(-lh4-) or 13(-lh5-) */
#define DICSIZ ((unsigned) 1 << DICBIT)
