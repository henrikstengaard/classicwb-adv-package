/*
**   $Filename: xpkarchivesub.h $
**   $Release: 2.0 $
**
**
**
**   (C) Copyright 1993,1994,1995 Matthias Meixner
**       All Rights Reserved
*/

#ifndef LIBRARIES_XARS_H
#define LIBRARIES_XARS_H

#include <libraries/xpkarchive.h>

struct XarSubHandle { /* Archive-handle */

/* public */

   BPTR  ArcFile;
   UBYTE *ArchiveName;       /* Read only ! */
   ULONG OpenMode;           /* Read only ! */
   ULONG Flags;              /* XARAF_...   */

   struct Library *MasterLib; /* Read only ! */
   struct Library *SubLib;    /* Read only ! */

   struct MinList ArcLocks;

   ULONG Reserved[8];

   ULONG Sub[4];              /* For private use of sublibs */

};

#define XARAF_Corrupt  1
#define XARAF_ShowDirs 2


struct XarSubLock { /* Archive  filelock */

/* public */

   struct MinNode Node;
   struct XarSubHandle *Arc;

   UBYTE  *FileName;
   UBYTE  *FileNote;

   struct XarFileData FileData;

   ULONG Reserved[4]; /* for future use */

};


struct XarSubIO {
   ULONG A4;            /* You must call all Hook-functions with this value*/
                        /* in register A4 (which is used by most compilers */
                        /* for the access to near-data)                    */
                        /* XarProgress() does that for you                 */

   UBYTE *IOMem;        /* One of these is !=NULL. This one specifies the  */
   BPTR  IOStream;      /* kind of the input/output. An archiver sublibrary*/
   struct Hook *IOHook; /* must at least support IOMem                     */
                        /* Exception: for directories all these are NULL   */

   long Size;           /* The length of the uncompressed file             */
   long Bufsize;        /* The length of the input-data for input          */
                        /* The length of the output-buffer for output      */

   struct Hook *ProgressHook; /* Pointer to the progress hookfunction. You */
                              /* call this one at least 2 times if !=NULL  */
                              /* for each file                             */

   UBYTE *FileName;     /* Filename to be used in the progresshook         */
   UBYTE *Password;     /* Password or NULL, if not needed                 */
   SHORT PackMode;      /* Packmode to be used for compression             */
};


struct XarSubInfo {

   USHORT  Sizeof;           /* sizeof(XarArchiverInfo)                 */

   USHORT SubVersion;        /* Version of the sublib                   */
   USHORT SubRevision;       /* Revision of the sublib                  */
   USHORT MasterVersion;     /* Required xpkarchive.library version     */

   struct XarArchiverInfo XarInfo;

   struct XpkMode *ModeDesc; /* List of individual descriptors          */

   UBYTE *Identify[8];       /* Indentify-pattern                       */

};


struct XarProgress {
   UBYTE *PackerName;
   UBYTE *LongName;
   UBYTE *ActActive;
   UBYTE *ActDone;

   ULONG State;      /* Private, don't touch, need not be initialized */
   ULONG Freq;
   ULONG StartTime;
   ULONG Time;
};


#define XARPROG_START      1
#define XARPROG_MID        2
#define XARPROG_END        3
#define XARPROG_DIRECTORY  4


#ifndef NO_XARS_PROTO

struct XarSubInfo * __saveds XarsArchiverInfo(void);
long __asm __saveds XarsCreateArchive(register __a0 struct XarSubHandle * );
long __asm __saveds XarsOpenArchive(register __a0 struct XarSubHandle * );
long __asm __saveds XarsCloseArchive(register __a0 struct XarSubHandle * );
long __asm __saveds XarsAddFile(register __a0 struct XarSubHandle * , register __a1 struct XarSubIO * , register __a2 struct XarSubLock ** );
long __asm __saveds XarsExtractFile(register __a0 struct XarSubLock * , register __a1 struct XarSubIO * );
long __asm __saveds XarsDeleteFile(register __a0 struct XarSubLock * );
long __asm __saveds XarsCopyFile(register __a0 struct XarSubLock ** , register __a1 struct XarSubHandle * );
long __asm __saveds XarsPackArchive(register __a0 struct XarSubHandle * , register __a1 struct XarSubHandle * );
long __asm __saveds XarsModifyFileData(register __a0 struct XarSubLock * , register __a1 struct XarFileData * );
long __asm __saveds XarsSetFilenote(register __a0 struct XarSubLock * , register __a1 const UBYTE * );
long __asm __saveds XarsRenameFile(register __a0 struct XarSubLock * , register __a1 const UBYTE * , register __d0 long );
long __asm __saveds XarsExamine(register __a0 struct XarSubLock * , register __a1 struct XpkFib * );
long __asm __saveds XarsUndeleteFile(register __a0 struct XarSubLock * );
long __asm __saveds XarsCmpFilename(register __a0 const UBYTE * , register __a1 const UBYTE * );
long __asm __saveds XarsAddDir(register __a0 struct XarSubHandle *, register __a1 struct XarSubIO *, register __a2 struct XarSubLock **);
UBYTE * __asm __saveds XarsWhy(register __a0 struct XarSubHandle *, register __d0 long);
LONG __saveds __asm XarsDirect(register __a0 struct XarSubHandle *arc, register __a1 const UBYTE *command);
LONG __saveds __asm XarsGetPackMode(register __a0 struct XarSubLock *lock, register __a1 struct XarPackMode *info);

#endif

#ifndef NO_XARS_PRAGMAS


#pragma libcall XarSubBase XarsArchiverInfo 1e 0
#pragma libcall XarSubBase XarsCreateArchive 24 801
#pragma libcall XarSubBase XarsOpenArchive 2a 801
#pragma libcall XarSubBase XarsCloseArchive 30 801
#pragma libcall XarSubBase XarsAddDir 36 A9803
#pragma libcall XarSubBase XarsAddFile 3c A9803
#pragma libcall XarSubBase XarsCmpFilename 42 9802
#pragma libcall XarSubBase XarsCopyFile 48 9802
#pragma libcall XarSubBase XarsDeleteFile 4e 801
#pragma libcall XarSubBase XarsExamine 54 9802
#pragma libcall XarSubBase XarsGetPackMode 54 9802
#pragma libcall XarSubBase XarsExtractFile 5a 9802
#pragma libcall XarSubBase XarsModifyFileData 60 9802
#pragma libcall XarSubBase XarsPackArchive 66 9802
#pragma libcall XarSubBase XarsRenameFile 6c 09803
#pragma libcall XarSubBase XarsSetFilenote 72 9802
#pragma libcall XarSubBase XarsDirect 78 9802
#pragma libcall XarSubBase XarsUndeleteFile 7e 801
#pragma libcall XarSubBase XarsWhy 84 0802

#endif

#endif

/* end xpkarchivesub.h */
